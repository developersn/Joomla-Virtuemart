<?php
defined('_JEXEC') or die('Restricted access');

$sessionData = SNApi::getData();
?>

<div class="sn-virtuemart">
    <div class="sn-virtuemart-msg">تراکنش با موفقیت انجام شد.</div>
    <div class="sn-virtuemart-au">شماره پیگیری : <?php echo isset($sessionData['bank_au']) ? $sessionData['bank_au'] : ''; ?></div>
</div>
<style>
    .sn-virtuemart-msg{
        color: #3c763d;
        background-color: #dff0d8;
        border: 1px solid #d6e9c6;
        padding: 10px;
        border-radius: 3px;
        font-size: 14px;
        text-align: center;
        margin: 3px auto;
    }
    .sn-virtuemart-au{
        color: #31708f;
        background-color: #d9edf7;
        border: 1px solid #bce8f1;
        padding: 10px;
        border-radius: 3px;
        font-size: 14px;
        text-align: center;
        margin: 3px auto;
    }
</style>