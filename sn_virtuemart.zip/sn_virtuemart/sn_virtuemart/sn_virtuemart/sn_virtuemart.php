<?php
defined('_JEXEC') or die();

jimport('sncore.include');

if(!class_exists('vmPSPlugin'))
{
    require(JPATH_VM_PLUGINS .DS. 'vmpsplugin.php');
}

class plgVmPaymentSn_virtuemart extends vmPSPlugin
{
    public static $_this = false;
    public $payment_method = 'sn_virtuemart';

    function __construct(& $subject, $config)
    {
        parent::__construct($subject, $config);

        SNGlobal::loadLanguage('plg_vmpayment_sn_virtuemart',JPATH_ADMINISTRATOR);

        $this->_loggable = true;
        $this->tableFields = array_keys($this->getTableSQLFields());
        $this->_tablepkey = 'id';
        $this->_tableId = 'id';

        $varsToPush = $this->getVarsToPush();

        $this->setConfigParameterable($this->_configTableFieldName,$varsToPush);
    }

    public function getVarsToPush ()
    {
        return self::getVarsToPushByXML($this->_xmlFile,$this->_name.'Form');
    }

    public function getVmPluginCreateTableSQL()
    {
        return $this->createTableSQL('Sn Payment Table');
    }

    function getTableSQLFields()
    {
        $sqlFields = array(
            'id'                          => 'int(1) UNSIGNED NOT NULL AUTO_INCREMENT',
            'virtuemart_order_id'         => 'int(1) UNSIGNED',
            'order_number'                => 'char(64)',
            'virtuemart_paymentmethod_id' => 'mediumint(1) UNSIGNED',
            'payment_name'                => 'varchar(5000)',
            'payment_order_total'         => 'decimal(15,5) NOT NULL DEFAULT \'0.00000\'',
            'payment_currency'            => 'char(3)',
            'email_currency'              => 'char(3)',
            'cost_per_transaction'        => 'decimal(10,2)',
            'cost_min_transaction'        => 'decimal(10,2)',
            'cost_percent_total'          => 'decimal(10,2)',
            'tax_id'                      => 'smallint(1)',
            'au'                          => 'char(50)',
        );

        return $sqlFields;
    }

    // before checkout
    function plgVmConfirmedOrder($cart,$order)
    {
        if(!class_exists('CurrencyDisplay'))
        {
            include JPATH_ADMINISTRATOR .DS. 'components'.DS.'com_virtuemart'.DS.'helpers'.DS.'currencydisplay.php';
        }

        $orderDetails = isset($order['details']['BT']) ? $order['details']['BT'] : $order['details']['ST'];
        $method = $this->getVmPluginMethod($orderDetails->virtuemart_paymentmethod_id);

        if (!$method || $method->payment_element != $this->payment_method)
        {
            return false;
        }

        $this->logInfo('Sn order number: ' . $orderDetails->order_number, 'message');

        if (!class_exists('VirtueMartModelOrders'))
        {
            require( JPATH_VM_ADMINISTRATOR .DS. 'models' .DS. 'orders.php' );
        }
        if (!class_exists('VirtueMartModelCurrency'))
        {
            require(JPATH_VM_ADMINISTRATOR .DS. 'models' .DS. 'currency.php');
        }

        $userCurrencyId = $order['details']['BT']->user_currency_id;
        $currency = CurrencyDisplay::getInstance($order['details']['BT']->user_currency_id, $order['details']['BT']->virtuemart_vendor_id);

        $totalFinal = $currency->roundForDisplay($order['details']['BT']->order_total, $userCurrencyId);

        $amount = $totalFinal;

        //insert data in created table for this plugin
        $dbValues = array();
        $dbValues['order_number'] = $orderDetails->order_number;
        $dbValues['payment_name'] = $this->renderPluginName($method);
        $dbValues['virtuemart_paymentmethod_id'] = $cart->virtuemart_paymentmethod_id;
        $dbValues['cost_per_transaction'] = $method->cost_per_transaction;
        $dbValues['cost_percent_total'] = $method->cost_percent_total;
        $dbValues['payment_currency'] = $method->payment_currency;
        $dbValues['payment_order_total'] = $amount;
        $dbValues['tax_id'] = $method->tax_id;
        $this->storePSPluginInternalData($dbValues);

        if($amount > 0)
        {
            $email = SNGlobal::filterVar($orderDetails->email,'email','');
            $phone = SNGlobal::filterVar($orderDetails->phone_2,'ir_phone','');
            $paymentMethodId = $orderDetails->virtuemart_paymentmethod_id;
            $orderNumber = $orderDetails->order_number;
            $orderId = $orderDetails->virtuemart_order_id;
            $backUrl = JURI::root() . "index.php?option=com_virtuemart&view=pluginresponse&task=pluginnotification&tmpl=component&on=".$orderNumber."&pm=".$paymentMethodId;

            $pin = $method->sn_pin;
            $currency = $method->sn_currency;
            $currency = in_array($currency,array(0,1)) ? $currency : 1;
            $sendPayerInfo = $method->sn_send_payer_info;
            $sendPayerInfo = in_array($sendPayerInfo,array(0,1)) ? $sendPayerInfo : 1;

            $amount = SNApi::modifyPrice($amount,$currency);
            
            $data = array(
                'pin'=> $pin,
                'price'=> $amount,
                'callback'=> $backUrl,
                'order_id'=> $orderId,
                'email'=> $email,
                'description'=> '',
                'mobile'=> $phone,
            );

            list($status,$msg,$resultData) = SNApi::request($data,$sendPayerInfo,'virtuemart');

            if($status != true)
            {
                $html = '<h5 style="color: #bb1111; font-size: 13px;" class="vm-not-connect">'.$msg.'</h5>';
            }
            else
            {
                $data['bank_callback_details'] = $resultData['bank_callback_details'];
                $data['au'] = $resultData['au'];

                SNApi::clearData();
                SNApi::setData($data);

                $storeData = array(
                    'au' => $resultData['au'],
                );
                $this->_storePaymentData($orderId,$storeData);

                $html = '<div class="sn-virtuemart-go-to-bank">'.JText::_('SN_CONNECTING_TO_PORTAL').'</div>';
                $html .= SNGlobal::postData($resultData['form_details']['action'],$resultData['form_details']['fields'],100);
            }

            $cart->_confirmDone = false;
            $cart->_dataValidated = false;
            $cart->setCartIntoSession();
            JRequest::setVar('html', $html);
        }
    }

    /* After Back From Bank */
    function plgVmOnPaymentNotification()
    {
        $itemId = SNGlobal::getVar('itemId');
        $paymentMethodId = SNGlobal::getVar('pm','','int','request');
        $orderNumber = SNGlobal::getVar('on','','none','request');
        $orderId = SNGlobal::getVar('order_id','','none','request');
        $au = SNGlobal::getVar('au','','none','request');

        if(!class_exists('VirtueMartModelOrders'))
        {
            require( JPATH_VM_ADMINISTRATOR .DS. 'models' .DS. 'orders.php' );
        }

        $method = $this->getVmPluginMethod($paymentMethodId);

        if(!($vmOrderId = VirtueMartModelOrders::getOrderIdByOrderNumber($orderNumber)))
        {
            return false;
        }

        if(!($payments = $this->getDatasByOrderId($vmOrderId)))
        {
            return false;
        }

        if(!$method || $method->payment_element != $this->payment_method)
        {
            return false;
        }

        $sessionData = SNApi::getData();
        if(empty($sessionData) || $sessionData['order_id'] != $orderId)
        {
            return false;
        }

        $this->logInfo('New Sn Transaction ['.$orderId.']','message');

        $orderId = VirtueMartModelOrders::getOrderIdByOrderNumber($orderNumber);
        $modelOrder = VmModel::getModel('orders');
        if($orderId != $sessionData['order_id'])
        {
            return false;
        }

        $bankData = array();
        foreach (!empty($sessionData['bank_callback_details']['params']) ? $sessionData['bank_callback_details']['params'] : array() as $bankParam)
        {
            $bankData[$bankParam] = !empty($_REQUEST[$bankParam]) ? $_REQUEST[$bankParam] : '';
        }

        $data = array (
            'pin' => $sessionData['pin'],
            'price' => $sessionData['price'],
            'order_id' => $sessionData['order_id'],
            'au' => $au,
            'bank_return' => $bankData,
        );

        list($status,$msg,$resultData) = SNApi::verify($data,'virtuemart');

        if($status == true)
        {
            $order['order_status'] = $this->_getPaidStatus($method);
            $order['comments'] = JText::_('SN_PAID_TRANSACTION');
            $order['customer_notified'] = 1;

            SNApi::setData(array('bank_au'=>$resultData['bank_au']));
        }
        else
        {
            $order['order_status'] = $this->_getUnpaidStatus($method);
            $order['comments'] = JText::_('SN_UNPAID_TRANSACTION');
            $order['customer_notified'] = 0;
        }

        $modelOrder->updateStatusForOneOrder($vmOrderId,$order,TRUE);

        $task = $status == true ? 'pluginresponsereceived' : 'pluginUserPaymentCancel';
        $url = 'index.php?option=com_virtuemart&view=pluginresponse&task='.$task.'&on='.$orderNumber.'&pm='.$paymentMethodId.(!empty($itemId) ? '&Itemid='.$itemId : '');
        $url = substr(JURI::root(false,''),0,-1) . JROUTE::_($url,false);
        SNGlobal::redirect($url);
    }

    // After Do Verify [paid]
    function plgVmOnPaymentResponseReceived(&$html)
    {
        $paymentMethodId = SNGlobal::getVar('pm','','int','request');
        $orderNumber = SNGlobal::getVar('on','','none','request');

        $method = $this->getVmPluginMethod($paymentMethodId);

        if (!$method || $method->payment_element != $this->payment_method)
        {
            return false;
        }

        if (!class_exists('VirtueMartCart'))
        {
            require(JPATH_VM_SITE . DS . 'helpers' . DS . 'cart.php');
        }
        if (!class_exists('shopFunctionsF'))
        {
            require(JPATH_VM_SITE . DS . 'helpers' . DS . 'shopfunctionsf.php');
        }
        if (!class_exists('VirtueMartModelOrders'))
        {
            require( JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'orders.php' );
        }

        $orderId = VirtueMartModelOrders::getOrderIdByOrderNumber($orderNumber);
        if(empty($orderId))
        {
            return null;
        }

        /* Empty Cart */
        $cart = VirtueMartCart::getCart();
        $cart->emptyCart();

        $virtuemartPluginRoot = JPATH_ROOT .DS. 'plugins' .DS. 'vmpayment' .DS. 'sn_virtuemart';
        $html = SNGlobal::loadView($virtuemartPluginRoot.DS.'layout'.DS.'default.php');

        return $html;
    }

    // After Do Verify [unpaid]
    function plgVmOnUserPaymentCancel()
    {
        $paymentMethodId = SNGlobal::getVar('pm','','int','request');
        $orderNumber = SNGlobal::getVar('on','','none','request');

        if(!class_exists('VirtueMartModelOrders'))
        {
            require( JPATH_VM_ADMINISTRATOR .DS. 'models' .DS. 'orders.php' );
        }

        $method = $this->getVmPluginMethod($paymentMethodId);

        if(!($vmOrderId = VirtueMartModelOrders::getOrderIdByOrderNumber($orderNumber)))
        {
            return false;
        }

        if(!($payments = $this->getDatasByOrderId($vmOrderId)))
        {
            return false;
        }

        if(!$method || $method->payment_element != $this->payment_method)
        {
            return false;
        }

        VmInfo(Jtext::_('SN_UNPAID_TRANSACTION'));

        return true;
    }

    function plgVmgetPaymentCurrency($virtuemart_paymentmethod_id, &$paymentCurrencyId)
    {
        if (!($method = $this->getVmPluginMethod($virtuemart_paymentmethod_id)))
        {
            return null;
        }

        if (!$this->selectedThisElement($method->payment_element))
        {
            return false;
        }

        $this->getPaymentCurrency($method);
        $paymentCurrencyId = $method->payment_currency;
    }

    function _getPaidStatus($method)
    {
        if(isset($method->status_success) and $method->status_success != "")
        {
            return $method->status_success;
        }
        else
        {
            return 'C';
        }
    }

    function _getUnpaidStatus($method)
    {
        if(isset($method->status_pending) and $method->status_pending != "")
        {
            return $method->status_pending;
        }
        else
        {
            return 'P';
        }
    }

    function _storePaymentData($orderId,$data)
    {
        $updateStr = '';
        foreach ($data as $key => $value)
        {
            $updateStr .= "`".$key."`='".SNGlobal::escape($value)."',";
        }
        $updateStr = rtrim($updateStr,',');

        if(!empty($updateStr))
        {
            $query = "UPDATE `#__virtuemart_payment_plg_sn_virtuemart` SET ".$updateStr." WHERE `virtuemart_order_id`='".$orderId."'";
            SNGlobal::update($query);
        }
    }

    function plgVmOnShowOrderBEPayment($orderId,$paymentMethodId)
    {
        if(!$this->selectedThisByMethodId($paymentMethodId))
        {
            return null;
        }

        if(!($paymentTable = $this->_getSnVmData($orderId)))
        {
            return '';
        }

        $this->getPaymentCurrency($paymentTable);
        $q = 'SELECT `currency_code_3` FROM `#__virtuemart_currencies` WHERE `virtuemart_currency_id`="' . $paymentTable->payment_currency . '" ';
        $db = &JFactory::getDBO();
        $db->setQuery($q);
        $currency_code_3 = $db->loadResult();
        $html = '<table class="adminlist">' . "\n";
        $html .= $this->getHtmlHeaderBE();
        $html .= $this->getHtmlRowBE('درگاه پرداخت جامع جومبانک', $paymentTable->payment_name);
        $code = "";
        foreach ($paymentTable as $key => $value)
        {
            if (substr($key, 0, strlen($code)) == $code)
            {
                $html .= $this->getHtmlRowBE($key, $value);
            }
        }
        $html .= '</table>' . "\n";
        return $html;
    }

    function _getSnVmData($vmOrderId,$orderNumber='')
    {
        $db = JFactory::getDBO();
        $query = 'SELECT * FROM `' . $this->_tablename . '` WHERE ';
        if($orderNumber)
        {
            $query .= " `order_number` = '" . $orderNumber . "'";
        }
        else
        {
            $query .= ' `virtuemart_order_id` = ' . $vmOrderId;
        }

        $db->setQuery($query);
        $result = $paymentTable = $db->loadObject();
        return !empty($result) ? $result : '';
    }


    function _getPaymentResponseHtml($vmTable,$paymentName)
    {
        $html = '<table>' . "\n";
        $html .= $this->getHtmlRow('درگاه پرداخت جامع جومی',$paymentName);
        if (!empty($vmTable))
        {
            $html .= $this->getHtmlRow('شماره سفارش', $vmTable->order_number);
        }
        $html .= '</table>' . "\n";

        return $html;
    }

    function getCosts(VirtueMartCart $cart, $method, $cart_prices)
    {
        if (preg_match('/%$/', $method->cost_percent_total)) {
            $cost_percent_total = substr($method->cost_percent_total, 0, -1);
        } else {
            $cost_percent_total = $method->cost_percent_total;
        }
        return ($method->cost_per_transaction + ($cart_prices['salesPrice'] * $cost_percent_total * 0.01));
    }

    /* Check Condition To Use This Portal Or No */
    protected function checkConditions($cart,$method,$cartPrices)
    {
        $amount = $this->getCartAmount($cartPrices);

        if($this->_toConvert)
        {
            $this->convertToVendorCurrency($method);
        }

        $amountCondition = ($amount >= $method->min_amount AND $amount <= $method->max_amount OR ($method->min_amount <= $amount AND ($method->max_amount == 0)));
        if(!$amountCondition)
        {
            return false;
        }

        $countries = array();
        if (!empty($method->countries))
        {
            if (!is_array($method->countries))
            {
                $countries[0] = $method->countries;
            }
            else
            {
                $countries = $method->countries;
            }
        }
        $address = (($cart->ST == 0) ? $cart->BT : $cart->ST);
        $country = isset($address['virtuemart_country_id']) ? $address['virtuemart_country_id'] : 0;

        if(!(in_array($country,$countries) || count($countries) == 0))
        {
            return false;
        }

        return true;
    }


    function plgVmOnStoreInstallPaymentPluginTable($jplugin_id)
    {
        return $this->onStoreInstallPluginTable($jplugin_id);
    }

    function plgVmDeclarePluginParamsPaymentVM3(&$data)
    {
        return $this->declarePluginParams('payment',$data);
    }

    public function plgVmOnSelectCheckPayment(VirtueMartCart $cart)
    {
        return $this->OnSelectCheck($cart);
    }

    public function plgVmDisplayListFEPayment(VirtueMartCart $cart, $selected = 0, &$htmlIn)
    {
        return $this->displayListFE($cart, $selected, $htmlIn);
    }

    public function plgVmonSelectedCalculatePricePayment(VirtueMartCart $cart, array &$cart_prices, &$cart_prices_name)
    {
        return $this->onSelectedCalculatePrice($cart, $cart_prices, $cart_prices_name);
    }

    function plgVmOnCheckAutomaticSelectedPayment(VirtueMartCart $cart, array $cart_prices = array())
    {
        return $this->onCheckAutomaticSelected($cart, $cart_prices);
    }

    public function plgVmOnShowOrderFEPayment($virtuemart_order_id, $virtuemart_paymentmethod_id, &$payment_name)
    {
        $this->onShowOrderFE($virtuemart_order_id, $virtuemart_paymentmethod_id, $payment_name);
    }


    function plgVmonShowOrderPrintPayment($order_number, $method_id)
    {
        return $this->onShowOrderPrint($order_number, $method_id);
    }

    function plgVmDeclarePluginParamsPayment($name, $id, &$data)
    {
        return $this->declarePluginParams('payment', $name, $id, $data);
    }

    function plgVmSetOnTablePluginParamsPayment($name, $id, &$table)
    {
        return $this->setOnTablePluginParams($name, $id, $table);
    }
}